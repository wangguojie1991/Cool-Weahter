/** An HTTP+HTTP/2 client for Android and Java applications. */
@javax.annotation.ParametersAreNonnullByDefault
package okhttp3;
